Placemoir press kit
A field journal for places. https://placemoir.app/press.html

icon/          App icons, 1024 px, no transparency. "placemoir-icon" is the default (map); "alternate" is the bookmark icon.
logo/          Mark, wordmark and lockups. SVG (outlined) and PNG (2048 px; 512 px for the mark).
               ink and moss are for light backgrounds; paper, white and moss-dark for dark ones.
art/           App Store header art, 3840 x 1646, light and dark.
devices/       Framed iPhone, iPad and iPhone Duo images with transparent backgrounds, light and dark.
screenshots/   Full-size screens, light and dark. These are from the pre-release build and may change before launch.

Please write the name as Placemoir (one word, capital P), and don't recolor, stretch or redraw the icon or logo.
Say it PLACE-mwahr, like "place" plus "memoir".
Placemoir is made by Tweeting Birds LLC. Screenshots and artwork (c) 2026 Tweeting Birds LLC; free to use in coverage of Placemoir.
